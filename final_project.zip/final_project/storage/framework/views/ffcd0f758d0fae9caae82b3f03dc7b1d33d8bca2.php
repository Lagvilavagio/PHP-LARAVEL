<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1">
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <a href="<?php echo e(route('student', $student->id)); ?>" class="underline text-black-50 dark:text-white">
                <?php echo e($student->name); ?>

            </a>
        </div>
        <div class="ml-12">
            <?php $__currentLoopData = $student->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                    <a href="<?php echo e(route('class', $class->id)); ?>" class="underline  dark:text-white">
                        <?php echo e($class->class_name); ?>

                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giorgi/Desktop/final_project/resources/views/students.blade.php ENDPATH**/ ?>