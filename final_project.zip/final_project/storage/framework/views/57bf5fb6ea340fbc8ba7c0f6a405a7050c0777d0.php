<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 md:grid-cols-2">
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <a href="<?php echo e(route('class', $class->id)); ?>" class="underline text-black-50 dark:text-white">
                    <?php echo e($class->class_name); ?>

                </a>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giorgi/Desktop/final_project/resources/views/classes.blade.php ENDPATH**/ ?>