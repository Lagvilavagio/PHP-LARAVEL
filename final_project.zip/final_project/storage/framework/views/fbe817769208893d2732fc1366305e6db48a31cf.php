<?php $__env->startSection('content'); ?>
<div>
    <a href="<?php echo e(route('student', $student->id)); ?>">
        <?php echo e($student->name); ?>

    </a>


    <div class="ml-12 class">
        <?php $__currentLoopData = $student->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <div class="ml-4 text-lg leading-7 font-semibold">

                            <li><?php echo e($class->class_name); ?></li>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="class">
            <form method="post" action="<?php echo e(route('change_class',$student->id)); ?>">
                <div class="form-group">
                    <label for="exampleInputEmail1"></label>
                    <select name="classes[]" id="" multiple>
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a><?php echo e($class->class_name); ?></a>
                            <option value="<?php echo e($class->id); ?>"><?php echo e($class->class_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="hidden" name="_token" id="csrf_token" value="<?php echo e(csrf_token()); ?>">
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giorgi/Desktop/final_project/resources/views/student.blade.php ENDPATH**/ ?>