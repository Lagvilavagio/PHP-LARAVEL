<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($user->is_admin): ?>
                <div class="card">
                    <a href="<?php echo e(url('/classes')); ?>" class="text-sm text-gray-700 underline">classes</a>
                    <a href="<?php echo e(url('/students')); ?>" class="text-sm text-gray-700 underline">students</a>
                    <a href="<?php echo e(url('/create_class')); ?>" class="text-sm text-gray-700 underline">add class</a>
                </div>
                <?php else: ?>
                <div>
                    <a href="<?php echo e(url('/my_classes')); ?>" class="text-sm text-gray-700 underline">my_classes</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giorgi/Desktop/final_project/resources/views/index.blade.php ENDPATH**/ ?>