<?php echo e($slot); ?>

<?php /**PATH /home/giorgi/Desktop/final_project/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>