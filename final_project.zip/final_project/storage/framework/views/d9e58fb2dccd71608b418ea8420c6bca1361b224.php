<div>
    <?php echo e($class->class_name); ?>

    <div class="ml-12">
        <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div  class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                <a href="<?php echo e(route('student', $student->id)); ?>">
                    <?php echo e($student->name); ?>

                </a>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/giorgi/Desktop/final_project/resources/views/class.blade.php ENDPATH**/ ?>