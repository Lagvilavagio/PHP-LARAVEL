




    <form id="add_form">
        <div class="box-body">
            <div class="form-group">
                <label for="exampleInputEmail1">class title</label>
                <input type="text" class="form-control" placeholder="class_name" name="class_name">
            </div>
        </div>
        <input type="hidden" name="_token" id="csrf_token" value="<?php echo e(csrf_token()); ?>">
        <div class="box-footer">
            <button type="submit" class="btn btn-primary btn-submit">Save</button>
        </div>
    </form>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

    <script type="text/javascript">
$(document).ready(function (){
    $('#add_form').on('submit', function (e){
        e.preventDefault();
        $.ajax({
            type: "POST",
            url:"<?php echo e(route('create_class.save')); ?>",
            data: $('#add_form').serialize(),
            success: function (response){
                alert("class added");
                // location.reload();
            },
            error: function (error){
                console.log(error)
                alert("class not added")
            }
        });
    });
});











    </script>

<?php /**PATH /home/giorgi/Desktop/final_project/resources/views/add_class.blade.php ENDPATH**/ ?>